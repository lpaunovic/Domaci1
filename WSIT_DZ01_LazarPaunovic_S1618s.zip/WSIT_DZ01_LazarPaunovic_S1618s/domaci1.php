<?php
$ime = "Lazar";
$prezime = "Paunovic";
$index = "16s";

echo "Ime: $ime <br>";
echo "Prezime: $prezime <br>";
echo "Broj Indeksa: $index";
?>